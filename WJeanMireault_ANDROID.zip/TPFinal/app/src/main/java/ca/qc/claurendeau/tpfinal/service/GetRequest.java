package ca.qc.claurendeau.tpfinal.service;

import android.os.AsyncTask;

import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;

public class GetRequest<T> extends AsyncTask<Object, Void, T> {

    private HttpURLConnection httpURLConnection;
    private URL url;
    private ObjectMapper objectMapper;
    final Class<?> typeParameterClass;

    public GetRequest(Class<?> typeParameterClass) {
        this.typeParameterClass = typeParameterClass;
        try {
            this.typeParameterClass.newInstance();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void setRequestProperties() {
        try {
            httpURLConnection.setDoInput(true);
            httpURLConnection.setDoOutput(false);
            httpURLConnection.setRequestMethod("GET");
            httpURLConnection.setRequestProperty("Accept", "application/json");
            httpURLConnection.setRequestProperty("Content-type", "application/json; utf8");
            httpURLConnection.connect();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void establishConnection(String url) {
        try {
            this.url = new URL(url);
            httpURLConnection = (HttpURLConnection) this.url.openConnection();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private T readData() throws IOException {
        StringBuilder stringBuilder = new StringBuilder();

        try {
            InputStreamReader inputStreamReader = new InputStreamReader(httpURLConnection.getInputStream());
            BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
            String line = "";
            while ((line = bufferedReader.readLine()) != null) {
                stringBuilder.append(line + "\n");
            }
            httpURLConnection.disconnect();
            return (T) objectMapper.readValue(stringBuilder.toString(), typeParameterClass);
        } catch (Exception e) {
            // Ignored
        }

        return null;
    }

    @Override
    protected T doInBackground(Object... objects) {
        try {
            String url = (String) objects[0];
            objectMapper = new ObjectMapper();
            objectMapper.setDateFormat(new SimpleDateFormat("yyyy-MM-dd"));

            establishConnection(url);
            setRequestProperties();

            return readData();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }
}
