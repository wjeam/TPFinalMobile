package ca.qc.claurendeau.tpfinal;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import ca.qc.claurendeau.tpfinal.model.Citizen;
import ca.qc.claurendeau.tpfinal.model.Permit;
import ca.qc.claurendeau.tpfinal.service.GetRequest;
import ca.qc.claurendeau.tpfinal.service.PostRequest;

public class LoginActivity extends AppCompatActivity {

    private EditText email;
    private EditText pword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        email = findViewById(R.id.email);
        pword = findViewById(R.id.pword);
    }

    public void onBack(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    public void onLogin(View view) {
        try {
            Citizen citizen = new Citizen();
            citizen.email = email.getText().toString();
            citizen.password = pword.getText().toString();
            citizen = new PostRequest<Citizen>(Citizen.class).execute("http://138.197.169.107:9898/login", citizen).get();
            if (citizen == null)
                Toast.makeText(this, "Invalid login.", Toast.LENGTH_LONG).show();
            else {
                Intent intent = new Intent(this, DashboardActivity.class);
                intent.putExtra("citizen", citizen);
                intent.putExtra("permit", new GetRequest<Permit>(Permit.class).execute("http://138.197.169.107:9898/permit/" + citizen.id).get());
                startActivity(intent);
            }
        } catch (Exception e) {
            // Ignore
        }
    }
}