package ca.qc.claurendeau.tpfinal;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.concurrent.ExecutionException;

import ca.qc.claurendeau.tpfinal.model.Citizen;
import ca.qc.claurendeau.tpfinal.model.Permit;
import ca.qc.claurendeau.tpfinal.service.GetRequest;
import ca.qc.claurendeau.tpfinal.service.PostRequest;

public class RegisterActivity extends AppCompatActivity {

    private EditText email;
    private EditText pword;
    private EditText cpword;
    private EditText hin;
    private EditText address;
    private EditText pnumber;
    private CheckBox isPermitTest;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        email = findViewById(R.id.email);
        pword = findViewById(R.id.pword);
        cpword = findViewById(R.id.cpword);
        hin = findViewById(R.id.hin);
        address = findViewById(R.id.address);
        pnumber = findViewById(R.id.pnumber);
        isPermitTest = findViewById(R.id.checkBox);
    }

    public void onClick(View view) {
        try {
            register();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void register() {
        try {
            if (valid() && passwordsMatch()) {
                Citizen newCitizen = getCitizenFromMinister();
                if (newCitizen != null) {
                    buildCitizenObject(newCitizen);
                    createCitizen(newCitizen);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void createCitizen(Citizen citizen) throws ExecutionException, InterruptedException {
        citizen.id = 0;
        Citizen responseEntity = new PostRequest<Citizen>(Citizen.class).execute("http://10.0.2.2:9898/register/", citizen).get();
        if (responseEntity != null) {
            createPermit(responseEntity);
            startActivity(new Intent(this, LoginActivity.class));
        } else {
            Toast.makeText(this, "E-mail or HIN already taken.", Toast.LENGTH_LONG).show();
        }
    }

    private void createPermit(Citizen citizen) {
        Permit newPermit = new Permit();
        newPermit.citizen = citizen;
        if (isPermitTest.isChecked()) {
            new PostRequest<Permit>(Permit.class).execute("http://10.0.2.2:9898/permit/vaccine", newPermit);
        } else {
            new PostRequest<Permit>(Permit.class).execute("http://10.0.2.2:9898/permit/test", newPermit);
        }
    }

    private Citizen getCitizenFromMinister() throws ExecutionException, InterruptedException {
        Citizen newCitizen = new GetRequest<Citizen>(Citizen.class).execute("http://10.0.2.2:9797/citizen/" + hin.getText().toString()).get();
        if (newCitizen == null) {
            Toast.makeText(this, "Invalid health insurance number.", Toast.LENGTH_LONG).show();
            return null;
        }
        return newCitizen;
    }

    private boolean valid() {
        String hinText = hin.getText().toString();
        String emailText = email.getText().toString();
        String pwordText = pword.getText().toString();
        String cpwordText = cpword.getText().toString();
        String addressText = address.getText().toString();
        String pnumberText = pnumber.getText().toString();

        if (hinText.trim().isEmpty() || emailText.trim().isEmpty() || pwordText.trim().isEmpty() || cpwordText.trim().isEmpty() || addressText.trim().isEmpty() || pnumberText.trim().isEmpty()) {
            Toast.makeText(this, "All fields need to be filled.", Toast.LENGTH_LONG).show();
            return false;
        } else
            return true;
    }

    private boolean passwordsMatch() {
        if (!pword.getText().toString().equals(cpword.getText().toString()))
            Toast.makeText(this, "Password do not match.", Toast.LENGTH_LONG).show();

        return pword.getText().toString().equals(cpword.getText().toString());
    }

    private void buildCitizenObject(Citizen citizen) {
        citizen.email = email.getText().toString();
        citizen.password = pword.getText().toString();
        citizen.address = address.getText().toString();
        citizen.phoneNumber = pnumber.getText().toString();
    }

    public void onBack(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}