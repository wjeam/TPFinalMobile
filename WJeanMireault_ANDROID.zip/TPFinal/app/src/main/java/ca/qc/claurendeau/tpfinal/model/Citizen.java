package ca.qc.claurendeau.tpfinal.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.io.Serializable;
import java.util.Date;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Citizen extends User implements Serializable {
    public String gender;

    public String ageCategory;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    public Date birthDate;

    public String phoneNumber;

    public String address;

    public String healthInsuranceNumber;

    public Citizen parent;
}