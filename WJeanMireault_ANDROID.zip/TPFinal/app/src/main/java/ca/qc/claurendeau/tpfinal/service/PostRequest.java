package ca.qc.claurendeau.tpfinal.service;

import android.os.AsyncTask;

import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;

import ca.qc.claurendeau.tpfinal.model.Citizen;

public class PostRequest<T> extends AsyncTask<Object, Void, T> {

    private HttpURLConnection httpURLConnection;
    private URL url;
    private ObjectMapper objectMapper;
    final Class<?> typeParameterClass;

    public PostRequest(Class<?> typeParameterClass) {
        this.typeParameterClass = typeParameterClass;
        try {
            this.typeParameterClass.newInstance();
        } catch (Exception e){
            e.printStackTrace();
        }
    }

    private void setRequestProperties(){
        try {
            httpURLConnection.setDoInput(true);
            httpURLConnection.setDoOutput(true);
            httpURLConnection.setRequestMethod("POST");
            httpURLConnection.setRequestProperty("Accept", "application/json");
            httpURLConnection.setRequestProperty("Content-type", "application/json; utf8");
        } catch (Exception e){
            e.printStackTrace();
        }
    }

    private void establishConnection(String url){
        try {
            this.url = new URL(url);
            httpURLConnection = (HttpURLConnection) this.url.openConnection();
        } catch (Exception e){
            e.printStackTrace();
        }
    }

    private void sendData(T object){
        try {
            String requestBody = objectMapper.writeValueAsString(object);
            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(httpURLConnection.getOutputStream(), "UTF-8");
            outputStreamWriter.write(requestBody);
            outputStreamWriter.close();
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    private T readData(){
        try {
            InputStreamReader inputStreamReader = new InputStreamReader(httpURLConnection.getInputStream());
            BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
            String line = "";
            StringBuilder stringBuilder = new StringBuilder();
            while ((line = bufferedReader.readLine()) != null) {
                stringBuilder.append(line + "\n");
            }
            return (T) objectMapper.readValue(stringBuilder.toString(), typeParameterClass);
        }catch (Exception e){
            // Ignored
        }
        return null;
    }

    @Override
    protected T doInBackground(Object... objects) {
        try {
            String url = (String) objects[0];
            T object = (T) objects[1];
            objectMapper = new ObjectMapper();
            objectMapper.setDateFormat(new SimpleDateFormat("yyyy-MM-dd"));

            establishConnection(url);
            setRequestProperties();
            sendData(object);
            return readData();
        }catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }
}
