package ca.qc.claurendeau.tpfinal;

import android.content.Intent;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Base64;

import ca.qc.claurendeau.tpfinal.model.Citizen;
import ca.qc.claurendeau.tpfinal.model.Permit;
import ca.qc.claurendeau.tpfinal.service.GetRequest;
import ca.qc.claurendeau.tpfinal.service.PostRequest;

public class DashboardActivity extends AppCompatActivity {

    private Citizen citizen;
    private Permit permit;

    private TextView email;
    private TextView pword;
    private TextView pnumber;
    private TextView fname;
    private TextView lname;
    private TextView gender;
    private TextView address;
    private TextView hin;
    private TextView bday;
    private TextView renewdate;
    private TextView ptype;
    private TextView renewlabel;
    private Button renewbtn;
    private ImageView qrCode;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        citizen = (Citizen) getIntent().getSerializableExtra("citizen");
        permit = (Permit) getIntent().getSerializableExtra("permit");

        email = findViewById(R.id.email2);
        lname = findViewById(R.id.lname);
        fname = findViewById(R.id.fname);
        gender = findViewById(R.id.gender);
        hin = findViewById(R.id.hin2);
        bday = findViewById(R.id.bday);
        ptype = findViewById(R.id.ptype);
        renewdate = findViewById(R.id.renewdate);
        renewlabel = findViewById(R.id.label_renew_date);
        renewbtn = findViewById(R.id.renew_btn);
        qrCode = findViewById(R.id.qr_code);

        initializeFields();
    }

    private void initializeFields(){
        byte[] byteImg = Base64.getDecoder().decode(permit.qrCodeBase64.getBytes());

        email.setText(citizen.email);
        gender.setText(citizen.gender);
        lname.setText(citizen.lastName);
        fname.setText(citizen.firstName);
        hin.setText(citizen.healthInsuranceNumber);
        bday.setText(new SimpleDateFormat("yyyy-MM-dd").format(citizen.birthDate));
        ptype.setText(permit.permitType);
        qrCode.setImageBitmap(BitmapFactory.decodeByteArray(byteImg, 0, byteImg.length));

        if(!permit.permitType.equals("Test")) {
            renewdate.setVisibility(View.INVISIBLE);
            renewlabel.setVisibility(View.INVISIBLE);
            renewbtn.setVisibility(View.INVISIBLE);
        }else
            renewdate.setText(new SimpleDateFormat("yyyy-MM-dd").format(permit.renewDate));
    }

    public void sendEmail(View view){
        new PostRequest<Citizen>(Citizen.class).execute("http://138.197.169.107:9898/email", citizen);
        Toast.makeText(this, "Email sent.", Toast.LENGTH_LONG).show();
    }

    public void onBack(View view){
        startActivity(new Intent(this, MainActivity.class));
    }

    public void renewPermit(View view){
        try {
            Permit tempPermit = new PostRequest<Permit>(Permit.class).execute("http://138.197.169.107:9898/permit/test/renew", permit).get();
            if(tempPermit == null)
                Toast.makeText(this, "Cannot renew permit as it is not expired.", Toast.LENGTH_LONG).show();
            else {
                renewdate.setText(new SimpleDateFormat("yyyy-MM-dd").format(tempPermit.renewDate));
            }
        }catch (Exception e){
            // Ignored
        }
    }
}