package ca.qc.claurendeau.minister.controller;

import ca.qc.claurendeau.minister.model.Citizen;
import ca.qc.claurendeau.minister.service.CitizenService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


@RestController
public class CitizenController {
    @Autowired
    private CitizenService citizenService;

    @GetMapping("/citizen/{healthInsuranceNumber}")
    public Citizen findCitizenByHealthInsuranceNumber(@PathVariable String healthInsuranceNumber) {
        return citizenService.findCitizenByHealthInsuranceNumber(healthInsuranceNumber);
    }
}
