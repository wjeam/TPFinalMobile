package ca.qc.claurendeau.minister.service;

import ca.qc.claurendeau.minister.model.Citizen;
import ca.qc.claurendeau.minister.repository.CitizenRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CitizenService {
    @Autowired
    private CitizenRepository citizenRepository;

    public Citizen findCitizenByHealthInsuranceNumber(String healthInsuranceNumber) {
        Citizen citizen = citizenRepository.findCitizenByHealthInsuranceNumber(healthInsuranceNumber);
        return (citizen != null && citizen.isHealthInsuranceValid()) ? citizen : null;
    }
}
