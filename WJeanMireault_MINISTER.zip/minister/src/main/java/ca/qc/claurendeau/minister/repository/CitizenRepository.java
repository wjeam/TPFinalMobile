package ca.qc.claurendeau.minister.repository;

import ca.qc.claurendeau.minister.model.Citizen;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CitizenRepository extends JpaRepository<Citizen, Integer> {
    public Citizen findCitizenByHealthInsuranceNumber(String healthInsuranceNumber);
}
