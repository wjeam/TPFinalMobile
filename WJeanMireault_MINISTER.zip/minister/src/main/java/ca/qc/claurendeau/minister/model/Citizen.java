package ca.qc.claurendeau.minister.model;

import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Data
@Entity
public class Citizen implements Serializable {
    @Id
    @GeneratedValue
    private int id;
    private String firstName;
    private String lastName;

    @Temporal(TemporalType.DATE)
    private Date birthDate;

    private String gender;
    private String healthInsuranceNumber;
    private boolean healthInsuranceValid;
}
