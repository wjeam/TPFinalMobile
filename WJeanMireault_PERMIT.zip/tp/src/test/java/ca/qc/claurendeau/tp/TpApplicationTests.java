package ca.qc.claurendeau.tp;

import ca.qc.claurendeau.tp.model.Citizen;
import ca.qc.claurendeau.tp.model.PermitTest;
import ca.qc.claurendeau.tp.model.PermitVaccine;
import ca.qc.claurendeau.tp.repository.CitizenRepository;
import ca.qc.claurendeau.tp.repository.PermitTestRepository;
import ca.qc.claurendeau.tp.service.CitizenService;
import ca.qc.claurendeau.tp.service.PermitService;
import ca.qc.claurendeau.tp.service.SystemService;
import org.junit.jupiter.api.TestInstance;
import org.springframework.boot.test.context.SpringBootTest;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Calendar;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class TpApplicationTests {

    @Autowired
    private PermitService permitService;

    @Autowired
    private CitizenService citizenService;

    @Autowired
    private CitizenRepository citizenRepository;

    @Autowired
    private PermitTestRepository permitTestRepository;

    @BeforeAll
    public void insertData(){
        Citizen citizen1 = new Citizen();
        citizen1.setEmail("user1");
        citizen1.setPassword("user1");
        citizen1.setHealthInsuranceNumber("user1");

        Citizen citizen2 = new Citizen();
        citizen2.setEmail("user2");
        citizen2.setPassword("user2");
        citizen2.setHealthInsuranceNumber("user2");

        Citizen citizen3 = new Citizen();
        citizen3.setEmail("user3");
        citizen3.setPassword("user3");
        citizen3.setHealthInsuranceNumber("user3");

        Citizen citizen4 = new Citizen();
        citizen4.setEmail("user4");
        citizen4.setPassword("user4");
        citizen4.setHealthInsuranceNumber("user4");

        citizenRepository.save(citizen1);
        citizenRepository.save(citizen2);
        citizenRepository.save(citizen3);
        citizenRepository.save(citizen4);
    }

    @Test
    public void testLogin(){
        assertNotNull(citizenService.login("user1", "user1"));
        assertNull(citizenService.login("bademail", "badpassword"));
    }

    @Test
    public void testRegister(){
        Citizen newCitizen = new Citizen();
        newCitizen.setEmail("user1");
        newCitizen.setPassword("user1");
        newCitizen.setHealthInsuranceNumber("user1");

        assertNull(citizenService.register(newCitizen));

        newCitizen.setEmail("newuser1");
        newCitizen.setHealthInsuranceNumber("newuser1");
        assertNotNull(citizenService.register(newCitizen));
    }

    @Test
    public void testEditInformation(){
        Citizen citizen = citizenRepository.findCitizenByEmail("user2");
        citizen.setEmail("newuser2");
        citizenService.editCitizen(citizen);
        assertNull(citizenRepository.findCitizenByEmail("user2"));
        assertNotNull(citizenRepository.findCitizenByEmail("newuser2"));
    }

    @Test
    public void testCreatePermitVaccine(){
        PermitVaccine permitVaccine = new PermitVaccine();
        permitVaccine.setCitizen(citizenRepository.findCitizenByEmail("user3"));
        assertNotNull(permitService.createPermitVaccine(permitVaccine));
        assertNull(permitService.createPermitVaccine(permitVaccine));
    }

    @Test
    public void testCreatePermitTest(){
        PermitTest permitTest = new PermitTest();
        Citizen citizen = citizenRepository.findCitizenByEmail("user4");
        permitTest.setCitizen(citizen);
        assertNotNull(permitService.createPermitTest(permitTest));
        assertNull(permitService.createPermitTest(permitTest));
    }

    @Test
    public void testRenewPermit(){
        Citizen citizen = citizenRepository.findCitizenByEmail("user4");
        PermitTest permitTest = permitTestRepository.findPermitTestByCitizenId(citizen.getId());
        Calendar renewDate = Calendar.getInstance();
        renewDate.setTime(permitTest.getRenewDate());
        permitService.renewTestPermit(citizen);
        permitTest = permitTestRepository.findPermitTestByCitizenId(citizen.getId());
        assertFalse(renewDate.getTime().before(permitTest.getRenewDate()));
    }
}
