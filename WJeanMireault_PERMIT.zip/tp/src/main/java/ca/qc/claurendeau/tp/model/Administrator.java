package ca.qc.claurendeau.tp.model;

import lombok.Data;

import javax.persistence.Entity;

@Entity
@Data
public class Administrator extends User {
}
