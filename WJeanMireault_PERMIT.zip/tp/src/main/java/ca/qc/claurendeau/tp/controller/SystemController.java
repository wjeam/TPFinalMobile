package ca.qc.claurendeau.tp.controller;

import ca.qc.claurendeau.tp.model.Citizen;
import ca.qc.claurendeau.tp.service.SystemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SystemController {
    @Autowired
    SystemService systemService;

    @PostMapping("/email")
    public void sendEmail(@RequestBody Citizen citizen) {
        systemService.sendEmail(citizen);
    }
}
