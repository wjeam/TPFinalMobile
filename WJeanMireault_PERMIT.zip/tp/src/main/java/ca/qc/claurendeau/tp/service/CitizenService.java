package ca.qc.claurendeau.tp.service;

import ca.qc.claurendeau.tp.model.Citizen;
import ca.qc.claurendeau.tp.repository.CitizenRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CitizenService {
    @Autowired
    CitizenRepository citizenRepository;

    public Citizen register(Citizen citizen) {
        if (citizen.getHealthInsuranceNumber() == null) return null;
        if (!isEmailOrHealthInsuranceNumberTaken(citizen.getEmail(), citizen.getHealthInsuranceNumber())) {
            return citizenRepository.saveAndFlush(citizen);
        } else
            return null;
    }

    public Citizen login(String email, String password) {
        try {
            Citizen citizen = citizenRepository.findCitizenByEmailAndPassword(email, password);
            return citizen;
        } catch (Exception e) {
            return null;
        }
    }

    public Citizen editCitizen(Citizen citizen) {
        Citizen tempCitizen = null;
        if (citizenRepository.findCitizenByEmail(citizen.getEmail()) == null)
            tempCitizen = citizenRepository.save(citizen);

        return tempCitizen;
    }

    private boolean isEmailOrHealthInsuranceNumberTaken(String email, String healthInsuranceNumber) {
        try {
            Citizen citizen = citizenRepository.findCitizenByEmailOrHealthInsuranceNumber(email, healthInsuranceNumber);
            return citizen != null;
        } catch (Exception e) {
            return true;
        }
    }

    public Citizen findCitizenByHealthInsuranceNumber(String healthInsuranceNumber) {
        return citizenRepository.findCitizenByHealthInsuranceNumber(healthInsuranceNumber);
    }

    public List<Citizen> findChildrenFromCitizenId(int id) {
        return citizenRepository.findAllByParentId(id);
    }
}
