package ca.qc.claurendeau.tp.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ca.qc.claurendeau.tp.model.Permit;
import org.springframework.data.jpa.repository.Query;

public interface PermitRepository extends JpaRepository<Permit, Integer> {
    public Permit findPermitByCitizenId(int id);
}