package ca.qc.claurendeau.tp;

import org.springframework.stereotype.Component;

@Component
public class Properties {
    private int renewDelayInDays = 14;
    private String permitVaccineEmailMessage = "Thank you for using our services.\nHere is your QR code for your vaccine permit regarding COVID.";
    private String permitTestEmailMessage = "Thank you for using our services.\nHere is your COVID test permit that will expire in " + renewDelayInDays + " days from now.";
    private int qrCodeWidth = 200;
    private int qrCodeHeight = 200;
    private String qrCodeFileExtension = "jpg";
    private String qrCodeFilename = "permit";
    private String pdfFilename = "permit.pdf";

    public int getRenewDelayInDays() {
        return renewDelayInDays;
    }

    public String getPermitVaccineEmailMessage() {
        return permitVaccineEmailMessage;
    }

    public String getPermitTestEmailMessage() {
        return permitTestEmailMessage;
    }

    public int getQrCodeWidth() {
        return qrCodeWidth;
    }

    public int getQrCodeHeight() {
        return qrCodeHeight;
    }

    public String getQrCodeFileExtension() {
        return qrCodeFileExtension;
    }

    public String getQrCodeFilename() {
        return qrCodeFilename;
    }

    public String getPdfFilename() {
        return pdfFilename;
    }
}
