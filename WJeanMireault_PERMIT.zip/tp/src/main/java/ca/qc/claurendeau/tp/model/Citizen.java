package ca.qc.claurendeau.tp.model;


import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
import java.util.Date;

@Entity
@Data
public class Citizen extends User {
    private String gender;

    private String ageCategory;

    @Temporal(TemporalType.DATE)
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date birthDate;

    private String phoneNumber;

    private String address;

    private String healthInsuranceNumber;

    @OneToOne(cascade = CascadeType.REFRESH)
    @JoinColumn(name = "parent_id", referencedColumnName = "id")
    private Citizen parent;

    @PrePersist
    public void prePersist() {
        if(birthDate == null) return;
        LocalDate currentDate = LocalDate.now();
        LocalDate birthDate = this.birthDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        int age = Period.between(birthDate, currentDate).getYears();
        this.ageCategory = getAgeCategory(age);
    }

    private String getAgeCategory(int age){
        if(age >= 0 && age <= 10)
            return "Children";
        else if(age >= 11 && age <= 17)
            return "Teenager";
        else if(age >= 18 && age <= 60)
            return "Adult";
        else
            return "Elderly";
    }
}