package ca.qc.claurendeau.tp.repository;

import ca.qc.claurendeau.tp.model.Citizen;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CitizenRepository extends JpaRepository<Citizen, Integer> {
    public Citizen findCitizenByEmail(String email);

    public Citizen findCitizenByEmailAndPassword(String email, String password);

    public Citizen findCitizenByEmailOrHealthInsuranceNumber(String email, String healthInsuranceNumber);

    public Citizen findCitizenByHealthInsuranceNumber(String healthInsuranceNumber);

    public List<Citizen> findAllByParentId(int id);
}
