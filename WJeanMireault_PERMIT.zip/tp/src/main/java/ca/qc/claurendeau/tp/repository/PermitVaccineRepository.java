package ca.qc.claurendeau.tp.repository;

import ca.qc.claurendeau.tp.model.PermitVaccine;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PermitVaccineRepository extends JpaRepository<PermitVaccine, Integer> {
    public PermitVaccine findPermitVaccineByCitizenId(int id);
}
