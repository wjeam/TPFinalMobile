package ca.qc.claurendeau.tp.model;

import lombok.Data;

import javax.persistence.*;
import java.util.Calendar;
import java.util.Date;

@Entity
@Data
@DiscriminatorValue(value = "Test")
public class PermitTest extends Permit {
    @Temporal(TemporalType.DATE)
    private Date renewDate;

    @PrePersist
    private void setRenewDate(){
        if(this.renewDate != null) return;
        Calendar c = Calendar.getInstance();
        c.setTime(new Date());
        c.add(Calendar.DAY_OF_MONTH, 14);
        this.renewDate = c.getTime();
    }
}
