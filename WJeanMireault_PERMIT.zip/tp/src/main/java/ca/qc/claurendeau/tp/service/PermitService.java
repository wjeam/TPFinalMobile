package ca.qc.claurendeau.tp.service;

import ca.qc.claurendeau.tp.Properties;
import ca.qc.claurendeau.tp.model.Citizen;
import ca.qc.claurendeau.tp.model.Permit;
import ca.qc.claurendeau.tp.model.PermitTest;
import ca.qc.claurendeau.tp.model.PermitVaccine;
import ca.qc.claurendeau.tp.repository.PermitRepository;
import ca.qc.claurendeau.tp.repository.PermitTestRepository;
import ca.qc.claurendeau.tp.repository.PermitVaccineRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Calendar;

@Service
public class PermitService {
    @Autowired
    private PermitTestRepository permitTestRepository;

    @Autowired
    private PermitVaccineRepository permitVaccineRepository;

    @Autowired
    private PermitRepository permitRepository;

    @Autowired
    private Properties properties;

    @Autowired
    private SystemService systemService;

    public PermitVaccine createPermitVaccine(PermitVaccine permitVaccine) {
        permitVaccine.setQrCodeBase64(systemService.getBase64QRCode(systemService.generateQRCode()));
        if(permitRepository.findPermitByCitizenId(permitVaccine.getCitizen().getId()) == null) {
            System.out.println(permitVaccine);
            return permitVaccineRepository.save(permitVaccine);
        }else
            return null;
    }

    public PermitTest createPermitTest(PermitTest permitTest) {
        permitTest.setQrCodeBase64(systemService.getBase64QRCode(systemService.generateQRCode()));
        if(permitRepository.findPermitByCitizenId(permitTest.getCitizen().getId()) == null)
            return permitTestRepository.save(permitTest);
        else
            return null;
    }

    public Permit renewTestPermit(Citizen citizen) {
        if (citizen == null) return null;
        PermitTest permit = permitTestRepository.findPermitTestByCitizenId(citizen.getId());
        if (permit == null || !isPermitExpired(permit)) return null;

        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_MONTH, properties.getRenewDelayInDays());

        permit.setRenewDate(calendar.getTime());
        return permitTestRepository.save(permit);
    }

    private boolean isPermitExpired(PermitTest permit) {
        Calendar currentDate = Calendar.getInstance();
        Calendar permitRenewDate = Calendar.getInstance();
        permitRenewDate.setTime(permit.getRenewDate());
        return permitRenewDate.getTime().before(currentDate.getTime());
    }

    public Permit findPermitByCitizenId(int id) {
        return permitRepository.findPermitByCitizenId(id);
    }
}
