package ca.qc.claurendeau.tp.controller;

import ca.qc.claurendeau.tp.model.Citizen;
import ca.qc.claurendeau.tp.service.CitizenService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class CitizenController {
    @Autowired
    CitizenService citizenService;

    @PostMapping("/register")
    public Citizen register(@RequestBody Citizen citizen) {
        return citizenService.register(citizen);
    }

    @PostMapping("/login")
    public Citizen login(@RequestBody Citizen citizen) {
        return citizenService.login(citizen.getEmail(), citizen.getPassword());
    }

    @GetMapping("/{hin}")
    public Citizen findCitizenByHealthInsuranceNumber(@PathVariable String hin){
        return citizenService.findCitizenByHealthInsuranceNumber(hin);
    }

    @GetMapping("/children/{id}")
    public List<Citizen> findChildrenFromCitizenId(@PathVariable int id){
        return citizenService.findChildrenFromCitizenId(id);
    }

    @PostMapping("/edit")
    public Citizen editCitizen(@RequestBody Citizen citizen){
        return citizenService.editCitizen(citizen);
    }
}
