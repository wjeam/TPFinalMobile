package ca.qc.claurendeau.tp.controller;

import ca.qc.claurendeau.tp.model.Citizen;
import ca.qc.claurendeau.tp.model.Permit;
import ca.qc.claurendeau.tp.model.PermitTest;
import ca.qc.claurendeau.tp.model.PermitVaccine;
import ca.qc.claurendeau.tp.service.PermitService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(path = "/permit", method = RequestMethod.POST)
public class PermitController {
    @Autowired
    PermitService permitService;

    @PostMapping("/vaccine")
    public PermitVaccine createPermitVaccine(@RequestBody PermitVaccine permitVaccine) {
        return permitService.createPermitVaccine(permitVaccine);
    }

    @PostMapping("/test")
    public PermitTest createPermitTest(@RequestBody PermitTest permitTest) {
        return permitService.createPermitTest(permitTest);
    }

    @GetMapping("/{id}")
    public Permit findPermitByCitizenId(@PathVariable int id){
        return permitService.findPermitByCitizenId(id);
    }

    @PostMapping("/test/renew")
    public Permit renewTestPermit(@RequestBody Citizen citizen){
        return permitService.renewTestPermit(citizen);
    }
}
