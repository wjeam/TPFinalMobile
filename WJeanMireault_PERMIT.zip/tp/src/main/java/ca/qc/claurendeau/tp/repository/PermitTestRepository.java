package ca.qc.claurendeau.tp.repository;

import ca.qc.claurendeau.tp.model.PermitTest;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PermitTestRepository extends JpaRepository<PermitTest, Integer> {
    public PermitTest findPermitTestByCitizenId(int id);
}
