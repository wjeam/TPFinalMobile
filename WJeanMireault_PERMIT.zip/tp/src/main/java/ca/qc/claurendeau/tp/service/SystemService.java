package ca.qc.claurendeau.tp.service;

import ca.qc.claurendeau.tp.Properties;
import ca.qc.claurendeau.tp.model.Citizen;
import ca.qc.claurendeau.tp.model.Permit;
import ca.qc.claurendeau.tp.repository.PermitRepository;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.itextpdf.text.Document;
import com.itextpdf.text.Image;
import com.itextpdf.text.pdf.PdfWriter;
import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import javax.imageio.ImageIO;
import javax.mail.internet.MimeMessage;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.Base64;
import java.util.UUID;

@Service
public class SystemService {

    @Autowired
    private Properties properties;

    @Autowired
    private JavaMailSender javaMailSender;

    @Autowired
    private PermitRepository permitRepository;

    public void sendEmail(Citizen citizen) {
        Permit permit = permitRepository.findPermitByCitizenId(citizen.getId());
        if (permit == null) return;
        byte[] qrCode = Base64.getDecoder().decode(permit.getQrCodeBase64());
        if (qrCode == null) return;

        ByteArrayOutputStream pdf = generatePDF(qrCode);

        try {
            MimeMessage mimeMessage = javaMailSender.createMimeMessage();
            MimeMessageHelper mimeMessageHelper = new MimeMessageHelper(mimeMessage, true);

            mimeMessageHelper.setTo(citizen.getEmail());
            if (permit.getPermitType().toLowerCase().equals("test"))
                mimeMessageHelper.setText(properties.getPermitTestEmailMessage());
            else
                mimeMessageHelper.setText(properties.getPermitVaccineEmailMessage());
            mimeMessageHelper.setSubject("COVID Permit");
            mimeMessageHelper.addAttachment(properties.getQrCodeFilename() + "." + properties.getQrCodeFileExtension(), new ByteArrayResource(IOUtils.toByteArray(new ByteArrayInputStream(qrCode))));
            mimeMessageHelper.addAttachment(properties.getPdfFilename(), new ByteArrayResource(IOUtils.toByteArray(new ByteArrayInputStream(pdf.toByteArray()))));

            javaMailSender.send(mimeMessage);
        } catch (Exception ignored) {
        }
    }

    public ByteArrayOutputStream generateQRCode() {
        try {
            BitMatrix bitMatrix = new QRCodeWriter().encode(UUID.randomUUID().toString(), BarcodeFormat.QR_CODE, properties.getQrCodeWidth(), properties.getQrCodeHeight());
            BufferedImage bufferedImage = MatrixToImageWriter.toBufferedImage(bitMatrix);
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            ImageIO.write(bufferedImage, properties.getQrCodeFileExtension(), byteArrayOutputStream);
            return byteArrayOutputStream;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public String getBase64QRCode(ByteArrayOutputStream byteArrayOutputStream) {
        return Base64.getEncoder().encodeToString(byteArrayOutputStream.toByteArray());
    }

    public ByteArrayOutputStream generatePDF(byte[] qrCodeStream) {
        if (qrCodeStream == null)
            return null;
        InputStream inputStream = new ByteArrayInputStream(qrCodeStream);
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        try {
            Document document = new Document();
            PdfWriter pdfWriter = PdfWriter.getInstance(document, byteArrayOutputStream);

            document.open();
            Image image = Image.getInstance(IOUtils.toByteArray(inputStream));
            document.add(image);

            document.close();
            pdfWriter.close();

            return byteArrayOutputStream;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
