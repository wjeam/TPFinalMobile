package ca.qc.claurendeau.tp.model;

import lombok.Data;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@Data
@DiscriminatorValue(value = "Vaccine")
public class PermitVaccine extends Permit {

}
